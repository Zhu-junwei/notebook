﻿$Global:UI = @{
    Width       = 50
    BorderColor = 'DarkCyan'
    BoxStyle    = 'Heavy'
    TitleColor  = 'Cyan'
    TextColor   = 'White'
    TextPaddingLeft = 2
    MutedColor  = 'DarkGray'
    AccentColor = 'Cyan'
}
