﻿$Global:UI = @{
    Width       = 50
    BorderColor = 'Blue'
    BoxStyle    = 'Single'
    TitleColor  = 'Green'
    TextColor   = 'Yellow'
    TextPaddingLeft = 2
    AccentColor = 'DarkYellow'
	MutedColor  = 'Gray'
}
