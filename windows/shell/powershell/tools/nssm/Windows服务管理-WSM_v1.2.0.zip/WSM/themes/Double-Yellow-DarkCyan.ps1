﻿$Global:UI = @{
    Width       = 50
    BorderColor = 'Yellow'
    BoxStyle    = 'Double'
    TitleColor  = 'Green'
    TextColor   = 'DarkCyan'
    TextPaddingLeft = 2
    AccentColor = 'DarkYellow'
	MutedColor  = 'Gray'
}
