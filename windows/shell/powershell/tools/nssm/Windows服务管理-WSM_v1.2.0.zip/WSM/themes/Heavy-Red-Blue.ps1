﻿$Global:UI = @{
    Width       = 50
    BorderColor = 'DarkRed'
    BoxStyle    = 'Heavy'
    TitleColor  = 'Red'
    TextColor   = 'DarkCyan'
    TextPaddingLeft = 2
    AccentColor = 'DarkYellow'
	MutedColor  = 'Gray'
}
