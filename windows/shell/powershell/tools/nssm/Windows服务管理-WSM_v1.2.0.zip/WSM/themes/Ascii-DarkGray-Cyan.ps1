﻿$Global:UI = @{
    Width       = 50
    BorderColor = 'DarkGray'
    BoxStyle    = 'Ascii'
    TitleColor  = 'DarkYellow'
    TextColor   = 'Cyan'
    TextPaddingLeft = 2
    AccentColor = 'DarkYellow'
	MutedColor  = 'Gray'
}
