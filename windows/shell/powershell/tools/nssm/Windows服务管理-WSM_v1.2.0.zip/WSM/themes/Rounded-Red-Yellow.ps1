﻿$Global:UI = @{
    Width       = 50
    BorderColor = 'Red'
    BoxStyle    = 'Rounded'
    TitleColor  = 'Green'
    TextColor   = 'Yellow'
    TextPaddingLeft = 2
    AccentColor = 'DarkYellow'
	MutedColor  = 'Gray'
}
